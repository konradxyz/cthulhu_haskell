/*
 * seq.h
 *
 *  Created on: 9 kwi 2015
 *      Author: kp306410
 */

#ifndef SEQ_H_
#define SEQ_H_

#include "static/seq/data.h"
#include "static/seq/instructions.h"
#include "static/utils/logging.h"



#endif /* SEQ_H_ */
