/*
 * value.cpp
 *
 *  Created on: Feb 17, 2015
 *      Author: kp
 */

#include "static/seq/data.h"
#include "static/utils/ptr.h"

namespace seq {



CallSpecification::~CallSpecification(){}
ContextUpdateRequest::~ContextUpdateRequest() {}
}
